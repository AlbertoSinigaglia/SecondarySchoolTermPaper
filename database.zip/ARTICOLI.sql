-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Mag 11, 2018 alle 23:35
-- Versione del server: 5.7.22-0ubuntu0.17.10.1
-- Versione PHP: 7.1.15-0ubuntu0.17.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WBA`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `ARTICOLI`
--

CREATE TABLE `ARTICOLI` (
  `CODICEARTICOLO` int(11) NOT NULL,
  `DESCRIZIONE` varchar(150) NOT NULL,
  `NOME` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `ARTICOLI`
--

INSERT INTO `ARTICOLI` (`CODICEARTICOLO`, `DESCRIZIONE`, `NOME`) VALUES
(1, 'lampadina alogena con bulbo di 2CM con gas argon da 500ore di durata con cavo H7', 'lampadina A1H7'),
(2, 'lampadina alogena con bulbo di 4CM con gas krypto da 300ore di durata con cavo H4', 'lampadina A2H4'),
(3, 'lampadina alogena con bulbo di 1CM con gas krypto-argon da 400ore di durata con cavo H2', 'A3H2'),
(4, 'lampadina xeno con bulbo di 1CM per fari xeno con gas xeno da 400ore di durata con cavo 5mm', 'lampada X1A5'),
(5, 'lampadina xeno con bulbo di 2CM per fari xeno con gas xeno da 600ore di durata con cavo 7mm', 'lampada X2A7');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `ARTICOLI`
--
ALTER TABLE `ARTICOLI`
  ADD PRIMARY KEY (`CODICEARTICOLO`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `ARTICOLI`
--
ALTER TABLE `ARTICOLI`
  MODIFY `CODICEARTICOLO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
