-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Mag 11, 2018 alle 23:37
-- Versione del server: 5.7.22-0ubuntu0.17.10.1
-- Versione PHP: 7.1.15-0ubuntu0.17.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WBA`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `DIPENDENTI`
--

CREATE TABLE `DIPENDENTI` (
  `EMAIL` varchar(30) NOT NULL,
  `TELEFONO` varchar(15) NOT NULL,
  `TELEFONO2` varchar(15) DEFAULT NULL,
  `PASSWORD` text NOT NULL,
  `RUOLO` enum('ResponsabileNC','AltriRuoli') NOT NULL,
  `NOME` varchar(50) DEFAULT NULL,
  `COGNOME` varchar(50) DEFAULT NULL,
  `ACCETTATO` bit(1) DEFAULT NULL,
  `REPARTO` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `DIPENDENTI`
--

INSERT INTO `DIPENDENTI` (`EMAIL`, `TELEFONO`, `TELEFONO2`, `PASSWORD`, `RUOLO`, `NOME`, `COGNOME`, `ACCETTATO`, `REPARTO`) VALUES
('alberto@bertazzo.net', '3526914870', NULL, 'password2', 'AltriRuoli', 'alberto', 'bertazzo', NULL, NULL),
('alice@carraro.it', '3256987410', NULL, 'password4', 'AltriRuoli', 'alice', 'carraro', NULL, NULL),
('as@as.as', '2323', '2323', '$2a$07$T2W4vQPm1/cJNADOJgQyfu9nwWZluTNKpiaYztEwftFKbEgdu/1kK', 'ResponsabileNC', 'prova', 'prova', b'1', NULL),
('asd@asd.asd', '123', '1212', '$2a$07$T2W4vQPm1/cJNADOJgQyfu9nwWZluTNKpiaYztEwftFKbEgdu/1kK', 'AltriRuoli', 'as', 'as', b'1', NULL),
('dsa@dsa.dsa', '321321321', '123123123', '$2a$07$T2W4vQPm1/cJNADOJgQyfu9nwWZluTNKpiaYztEwftFKbEgdu/1kK', 'AltriRuoli', 'dsa', 'dsa', b'1', NULL),
('eleonora@gemo.it', '3514896572', NULL, 'password3', 'AltriRuoli', 'eleonora', 'gemo', NULL, NULL),
('filippo@caldon.com', '3256987410', NULL, 'password1', 'AltriRuoli', 'filippo', 'caldon', NULL, NULL),
('francescoverdi@gmail.com', '5466842168945', NULL, 'password6', 'AltriRuoli', 'francesco', 'verdi', NULL, NULL),
('leonardoneri@gmail.com', '458754684369', NULL, 'password7', 'AltriRuoli', 'leonardo', 'neri', NULL, NULL),
('sasda@adasd', '342134', '234234', '$2a$07$FfAem4Copj9ncQFllzzxReOv6HJqXnAKCnIWcySSeCGg.Dfp33UpW', 'AltriRuoli', 'adsasd', 'asda', b'1', NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `DIPENDENTI`
--
ALTER TABLE `DIPENDENTI`
  ADD PRIMARY KEY (`EMAIL`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
