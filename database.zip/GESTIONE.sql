-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Mag 11, 2018 alle 23:38
-- Versione del server: 5.7.22-0ubuntu0.17.10.1
-- Versione PHP: 7.1.15-0ubuntu0.17.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WBA`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `GESTIONE`
--

CREATE TABLE `GESTIONE` (
  `NR` int(11) NOT NULL,
  `EMAIL` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `GESTIONE`
--

INSERT INTO `GESTIONE` (`NR`, `EMAIL`) VALUES
(9, 'asd@asd.asd'),
(3, 'leonardoneri@gmail.com'),
(4, 'sasda@adasd'),
(9, 'sasda@adasd');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `GESTIONE`
--
ALTER TABLE `GESTIONE`
  ADD PRIMARY KEY (`NR`,`EMAIL`),
  ADD KEY `EMAIL` (`EMAIL`);

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `GESTIONE`
--
ALTER TABLE `GESTIONE`
  ADD CONSTRAINT `GESTIONE_ibfk_1` FOREIGN KEY (`NR`) REFERENCES `NONCONFORMITA` (`NR`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `GESTIONE_ibfk_2` FOREIGN KEY (`EMAIL`) REFERENCES `DIPENDENTI` (`EMAIL`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
