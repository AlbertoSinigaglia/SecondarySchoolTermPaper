-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Mag 11, 2018 alle 23:36
-- Versione del server: 5.7.22-0ubuntu0.17.10.1
-- Versione PHP: 7.1.15-0ubuntu0.17.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WBA`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `CLIENTI`
--

CREATE TABLE `CLIENTI` (
  `PIVA` char(11) NOT NULL,
  `TELEFONO` varchar(15) NOT NULL,
  `TELEFONO2` varchar(15) DEFAULT NULL,
  `DENOM_AZIENDA` varchar(40) DEFAULT NULL,
  `PASSWORD` text NOT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `ACCETTATO` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `CLIENTI`
--

INSERT INTO `CLIENTI` (`PIVA`, `TELEFONO`, `TELEFONO2`, `DENOM_AZIENDA`, `PASSWORD`, `EMAIL`, `ACCETTATO`) VALUES
('11111111111', '3332165498', NULL, 'AZIENDA1', 'password1', 'AZIENDA1@AZIENDA1.COM', b'1'),
('12121212121', '12', '1212', 'asas', '$2a$07$T2W4vQPm1/cJNADOJgQyfu9nwWZluTNKpiaYztEwftFKbEgdu/1kK', 'prova@prova.it', b'1'),
('12312312312', '123', '123123', 'asd', '$2a$07$lUNrFt.EsNRoQJG/Ifzfkea6QRi9RmC9vTPktcRjtQpmy/nmDexZu', 'qwe@qwe.qwe', b'1'),
('22222222222', '3214569877', '3698521478', NULL, 'password3', 'MARIO@ROSSI.IT', NULL),
('23232323232', '3232', '2323', 'ee', '$2a$07$d.COg6HLL2OLamWvBpUSPOqg9G1YGLsezFpwYDlYS/c77SJc2tWoK', 'ee@ee.ee', b'0'),
('32132132121', '12', '21', 'asd', '$2a$07$lt1vDn7st5Dz5P4wnhH.Z.pShYHP36rfNa8eLFdwfl00t8Idkih9C', 'asd@asd.asd', b'1'),
('32132132132', '3232', '2121', 'ewq', '$2a$07$jH95kOv.Rk7BJFW0gH9gQ.RhaF9hNCghWNARHRTPEbDQjmMEPK5Yy', 'asd@asd.asd', b'0'),
('33333333333', '3578964120', NULL, 'AZIENDA3', 'password2', 'AZIENDA3@AZIENDA3.COM', NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `CLIENTI`
--
ALTER TABLE `CLIENTI`
  ADD PRIMARY KEY (`PIVA`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
